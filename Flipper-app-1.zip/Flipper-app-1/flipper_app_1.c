#include <furi.h>
#include <gui/gui.h>

int32_t flipper_app_1(void) {
    FuriString* str = furi_string_alloc();
    furi_string_printf(str, "Hello from GitHub!");
    NotificationApp* notification = furi_record_open("notification");
    notification_message(notification, &sequence_blink_red_10);
    furi_delay_ms(1000);
    furi_record_close("notification");
    furi_string_free(str);
    return 0;
}
